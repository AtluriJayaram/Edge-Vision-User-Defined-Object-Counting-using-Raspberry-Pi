import cv2

cap = cv2.VideoCapture('http://192.168.0.204:8000/stream.mjpg') 

output = cv2.VideoWriter("video_bright_4.mp4", cv2.VideoWriter_fourcc(*'MP4V'), 24, (640, 480) )

while True:
    ret, frame = cap.read()
    if not ret:
        break
    frame = cv2.flip(frame, 1)

    cv2.imshow('Video', frame)
    output.write(frame)

    if cv2.waitKey(1) & 0xFF == 27:  # Press Esc to exit
        break

cap.release()
output.release()
cv2.destroyAllWindows()